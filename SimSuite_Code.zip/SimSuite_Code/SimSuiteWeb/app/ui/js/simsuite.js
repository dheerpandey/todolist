﻿var events = new Events();
var isIE = isIE11();
$(document).ready(function () {   

    $('#date').bootstrapMaterialDatePicker
    ({
        time: false,
        clearButton: true
    });

    $('#time').bootstrapMaterialDatePicker
    ({
        date: false,
        shortTime: false,
        format: 'HH:mm:ss'
    });

    $('#date-format').bootstrapMaterialDatePicker
    ({
        format: 'dddd DD MMMM YYYY - HH:mm:ss'
    });
    $('#date-fr').bootstrapMaterialDatePicker
    ({
        format: 'DD/MM/YYYY HH:mm:ss',
        lang: 'fr',
        weekStart: 1,
        cancelText: 'ANNULER',
        nowButton: true,
        switchOnClick: true
    });

    $('#date-end').bootstrapMaterialDatePicker
    ({
        weekStart: 0, format: 'YYYY-MM-DD HH:mm:ss', shortTime: false
    });
    $('#date-start').bootstrapMaterialDatePicker
    ({
        weekStart: 0, format: 'YYYY-MM-DD HH:mm:ss', shortTime: false
    }).on('change', function (e, date) {
        $('#date-end').bootstrapMaterialDatePicker('setMinDate', date);
    });

    $('#min-date').bootstrapMaterialDatePicker({ format: 'DD/MM/YYYY HH:mm:ss', minDate: new Date() });
    $('#date-start').on('input change', function () {
        if ($.trim($(this).val()) !== "") {
            $('#date-start').closest("div").addClass('is-dirty');
        }
    });

    $('#date-end').on('input change', function () {
        if ($.trim($(this).val()) !== "") {
            $('#date-end').closest("div").addClass('is-dirty');
        }
    });

    $('#txtPipeline').prop('disabled', true);
    $('#txtEvent').prop('disabled', true);
    $('#date-start').prop('disabled', true);
    $('#date-end').prop('disabled', true);
    $('#Calculate').prop('disabled', true).removeClass('btn-color').addClass('btn-disable-color');

    $('#txtWorkspace').on('input change', function () {
        if ($.trim($(this).val()) !== "") {
            fillPipeline();
            $('#txtPipeline').prop('disabled', false);
        } else {
            $('#txtPipeline').val("");
            $('#txtEvent').val("");            
            $('#txtPipeline').prop('disabled', true).closest("div").removeClass('is-dirty');
            $('#txtEvent').prop('disabled', true).closest("div").removeClass('is-dirty');            
            $('#Calculate').prop('disabled', true).removeClass('btn-color').addClass('btn-disable-color');;
        }
    });

    $('#txtPipeline').on('input change', function () {
        if ($.trim($(this).val()) !== "") {
            fillEvent();
            $('#txtEvent').prop('disabled', false);
        } else {
            $('#txtEvent').val("");            
            $('#txtEvent').prop('disabled', true).closest("div").removeClass('is-dirty');            
            $('#Calculate').prop('disabled', true).removeClass('btn-color').addClass('btn-disable-color');
        }
    });
    $('#txtEvent').on('input change', function () {
        if ($.trim($(this).val()) !== "") {
            $('#date-start').prop('disabled', false).closest("div").removeClass('is-disabled');
            if ($.trim($('#date-start').val()) !== "" && $.trim($('#date-end').val()) !== "") {
                $('#Calculate').prop('disabled', false).removeClass('btn-disable-color').addClass('btn-color');
            }            
        } else {            
            $('#Calculate').prop('disabled', true).removeClass('btn-color').addClass('btn-disable-color');
        }
    });
    $('#date-start').on('input change', function () {
        $('#date-end').val("");
        $('#date-end').prop('disabled', true).closest("div").removeClass('is-dirty').removeClass('is-focused');
        $('#date-end').prop('disabled', false).closest("div").removeClass('is-disabled');
        $('#Calculate').prop('disabled', true).removeClass('btn-color').addClass('btn-disable-color');
    });
    $('#date-end').on('input change', function () {
        if ($.trim($(this).val()) !== "") {
            $('#Calculate').prop('disabled', false).removeClass('btn-disable-color').addClass('btn-color');
        } else {
            $('#Calculate').prop('disabled', true).removeClass('btn-color').addClass('btn-disable-color');
        }
    });

    $(".mdl-tabs__tab").on("click", function () {

        buildChart(this.hash);
    });

    $("#Calculate").on("click", function () {
        closeMenuDrawer();
        buildBreadcrumb();
        $("#SavePreferences").show();
        $(".chart-tab-content").show();
        $(".welcome-content").hide();
        loadChartConfig($("#txtWorkspace").val().trim(), $("#txtPipeline").val().trim(), events.Sections[0].trim(), $("#txtEvent").val().trim(), $("#date-start").val().trim(), $("#date-end").val().trim(), 10, 100);//[TO-DO last 2 parapeter should be dynamic]
        buildChart($($("#tab-short-averaging-period").attr("href")));
    });

    $("#SavePreferences").on("click", function () {
        var workspace = $("#txtWorkspace").val().trim();
        var pipeline = $("#txtPipeline").val().trim();
        var event = $("#txtEvent").val().trim();
        var startdate = $("#date-start").val().trim();
        var enddate = $("#date-end").val().trim();

        if (workspace && pipeline && event && startdate && enddate) {
            Preferences().Add(workspace, pipeline, event, startdate, enddate);
        }
    });

    $("#Calculate").on("mouseover", function () {
        var offset = $(this).offset();
        var leftOffset = isIE ? 30 : 60;
        $("#calculatetooltip").addClass("is-active")
                              .offset({ top: (offset.top + 50), left: (offset.left + leftOffset) });
    });

    $("#Calculate").on("mouseout", function () {
        $("#calculatetooltip").removeClass("is-active");
    });

    var objPreferences = Settings.Preferences.Get();
    if (objPreferences) {
        $("#txtWorkspace").val(objPreferences.Workspace);
        $("#txtPipeline").val(objPreferences.Pipeline);
        $("#txtEvent").val(objPreferences.Event);
        $("#date-start").val(objPreferences.DataStart);
        $("#date-end").val(objPreferences.DataEnd);

        fillWorkspace();
        fillPipeline();
        fillEvent();

        $('#txtPipeline').prop('disabled', false);
        $('#txtEvent').prop('disabled', false);
        $('#date-start').prop('disabled', false);
        $('#date-end').prop('disabled', false);
        $('#Calculate').prop('disabled', false).removeClass('btn-disable-color').addClass('btn-color');

        $("#Calculate").trigger("click");
    } else {
        $(".chart-tab-content").hide();
        $(".welcome-content").show();
        $('#settings').trigger("click");
    }
});

function getChartConfig(charttype) {
    return $.grep(chartConfig, function (e) { return e.charttype == charttype; });
}
function getChart(charttype) {
    return $.grep(charts, function (e) { return e.Charttype == charttype; });
}

var charts = [];
function buildChart(currentTab) {

    $(currentTab).load(Settings.TemplatePath + "chart.html", function () {

        renderChart(this);
        
        $(this).find("#recalculate").click(function () {
            var magnitude = "", hold = "", decay = "";

            $.each(charts, function (i, item) {
                magnitude += item.Threshhold[0].magnitude + ",";
                hold += item.Threshhold[2].holdtime + ",";
                decay += item.Threshhold[3].decaytime + ",";
            })

            var timeAfter = "1";
            var exclusion = "";
            var obChartConfig = getChartConfig($(currentTab).attr("type"));
            $.each(obChartConfig[0].config.data.datasets, function (i, item) {

                if (item.data.length && item.label != "Threshold") {
                    exclusion += (item.borderDash ? "1" : "0") + ",";
                }
            })

            var url = Settings.T3APIUrl + $("#txtWorkspace").val().trim() + "/" + $("#txtPipeline").val().trim() + "/" + $("#txtEvent").val().trim()
                + "/" + events.Sections[0].trim() + "/" + $("#date-start").val().trim() + "/" + $("#date-end").val().trim() + "/" + timeAfter
                + "/" + obChartConfig[0].threshold[1].basethreshold + "/" + exclusion.substring(0, exclusion.length - 1);

            var proxy = new ServiceProxy(url);
            var response = proxy.reCalculate();
            var tabIndex = $(this).closest(".mdl-tabs__panel").index();
            if (response && tabIndex <= response.length) {
                var index = tabIndex - 1;
                chartConfig[index].threshold[0].magnitude = response[index].magnitude;
                chartConfig[index].threshold[2].holdtime = response[index].hold;
                chartConfig[index].threshold[3].decaytime = response[index].decay;

                generateThresholdCoordinates(obChartConfig[0].config.data.datasets, obChartConfig[0].threshold[1].basethreshold, response[index].magnitude, response[index].hold, response[index].decay);

                renderChart("#" + $(".mdl-tabs__panel").filter(".is-active")[0].id);
            }
        });

        $(this).find("#updateConfig").click(function () {
            var magnitude = "", hold = "", decay = "";

            $.each(charts, function (i, item) {
                magnitude += item.Threshhold[0].magnitude + ",";
                hold += item.Threshhold[2].holdtime + ",";
                decay += item.Threshhold[3].decaytime + ",";
            })
            var url = Settings.T3APIUrl + $("#txtWorkspace").val().trim() + "/" + $("#txtPipeline").val().trim() + "/" + $("#txtEvent").val().trim() + "/" + magnitude.substring(0, magnitude.length - 1) + "/" + hold.substring(0, hold.length - 1) + "/" + decay.substring(0, decay.length - 1);
            var proxy = new ServiceProxy(url);
            var response = proxy.updateConfig();
        });
                
        var recaltooltip = $(this).find("#recalculatetooltip");
        $(this).find("#recalculate").on("mouseover", function () {
            var offset = $(this).offset();
            
            var leftOffset = isIE ? 30 : 60;
            recaltooltip.addClass("is-active")
                        .offset({ top: (offset.top - 50), left: (offset.left + leftOffset) });
        });
        $(this).find("#recalculate").on("mouseout", function () {
            recaltooltip.removeClass("is-active");
        });

        var upgradetooltip = $(this).find("#updateConfigtooltip");
        $(this).find("#updateConfig").on("mouseover", function () {
            var offset = $(this).offset()
            
            var leftOffset = isIE ? -15 : 40;
            upgradetooltip.addClass("is-active")
                        .offset({ top: (offset.top - 50), left: (offset.left + leftOffset)});
        });
        $(this).find("#updateConfig").on("mouseout", function () {
            upgradetooltip.removeClass("is-active");
        });
    });
}

function isIE11()
{
    return (!!navigator.userAgent.match(/Trident.*rv\:11\./));
}



function renderChart(currentTab) {
    var obChartConfig = getChartConfig($(currentTab).attr("type"));

    if (obChartConfig.length == 0) {
        throw "Missing Chart Configuration.";
    }

    if (obChartConfig[0].threshold.length == 0) {
        throw "Missing threshold from chart configuration.";
    }

    var result = getChart($(currentTab).attr("type"));
    if (result.length >= 0) {
        charts.pop(result);
    }

    var ctx = $(currentTab).find("canvas").get(0).getContext("2d");
    var chart = new Chart(ctx, obChartConfig[0].config);


    $(currentTab).find("#basethreshold")[0].value = obChartConfig[0].threshold[1].basethreshold;
    $(currentTab).find("#magnitude")[0].value = obChartConfig[0].threshold[0].magnitude;    
    $(currentTab).find("#holdtime")[0].value = obChartConfig[0].threshold[2].holdtime;
    $(currentTab).find("#decaytime")[0].value = obChartConfig[0].threshold[3].decaytime;
    if (!(typeof (componentHandler) == 'undefined')) {
        componentHandler.upgradeAllRegistered();        
    }

    setSliderLabel($(currentTab).find("#basethreshold")[0]);
    setSliderLabel($(currentTab).find("#magnitude")[0]);
    setSliderLabel($(currentTab).find("#holdtime")[0]);
    setSliderLabel($(currentTab).find("#decaytime")[0]); 

    var obj = new Object();
    obj.Charttype = $(currentTab).attr("type");
    obj.Chart = chart;

    obj.Threshhold = obChartConfig[0].threshold;

    charts.push(obj);
}

function setSliderLabel(slider) {
    var sliderpanel = $(slider).closest(".threshold-panel");
    $(sliderpanel.find("span[for='" + slider.id + "']")).html(slider.value);
}

function updateSlider(slider, value) {
    setSliderLabel(slider);

    var sliderpanel = $(slider).closest(".threshold-panel");
    var charttype = $(slider).closest(".mdl-tabs__panel.is-active").attr("type");

    updateChart(sliderpanel, charttype);
}

function updateChart(sliderpanel, charttype) {

    var chart = getChart(charttype);
    if (chart.length == 0) {
        return;
    }
    var basethreshold = parseFloat(sliderpanel.find("#basethreshold")[0].value);
    var magnitude = parseFloat(sliderpanel.find("#magnitude")[0].value);

    var holdtime = parseFloat(sliderpanel.find("#holdtime")[0].value);
    var decaytime = parseFloat(sliderpanel.find("#decaytime")[0].value);
    
    var obChartConfig = getChartConfig(charttype);

    generateThresholdCoordinates(obChartConfig[0].config.data.datasets, basethreshold, magnitude, holdtime, decaytime);

    //TO PERSIST SLIDER VALUES. WE NEED TO Get & SET SLIDER VALUES IN chart global object    
    obChartConfig[0].threshold = [{ "magnitude": magnitude }, { "basethreshold": basethreshold }, { "holdtime": holdtime }, { "decaytime": decaytime }];
    chart[0].Chart.config.data.datasets = obChartConfig[0].config.data.datasets;
    chart[0].Chart.update();
}

function generateThresholdCoordinates(chartDataset, basethreshold, magnitude, holdtime, decaytime) {
    var x2 = "";
    chartDataset.forEach(function (dataset) {

        if (dataset.label != "Threshold" && dataset.data.length > 0) {
            x2 = dataset.data[0].x;
        } else if (dataset.label == "Threshold") {
            var max = parseFloat(dataset.data[5].x);

            dataset.data[0].y = basethreshold;

            dataset.data[1].x = parseFloat(x2);
            dataset.data[1].y = basethreshold;
            if (max < dataset.data[1].x) {
                max = dataset.data[1].x;
            }

            dataset.data[2].x = dataset.data[1].x;
            dataset.data[2].y = basethreshold * magnitude;

            if (max < dataset.data[2].x) {
                max = dataset.data[2].x;
            }

            dataset.data[3].x = parseFloat(dataset.data[1].x) + holdtime;
            dataset.data[3].y = dataset.data[2].y;

            if (max < dataset.data[3].x) {
                max = dataset.data[3].x;
            }

            dataset.data[4].y = basethreshold;
            dataset.data[4].x = parseFloat(dataset.data[3].x) + decaytime;

            if (max < dataset.data[4].x) {
                max = dataset.data[4].x;
            }

            dataset.data[5].x = max;
            dataset.data[5].y = basethreshold;
        }
    })
}

function buildBreadcrumb() {
    var text = "";
    if ($("#txtWorkspace").val())
        text += $("#txtWorkspace").val();

    if ($("#txtPipeline").val())
        text += " > " + $("#txtPipeline").val();

    if ($("#txtEvent").val())
        text += " > " + $("#txtEvent").val();

    if ($("#date-start").val() && $("#date-end").val()) {
        text += " > (" + $("#date-start").val() + " AND " + $("#date-end").val() + ")";
    }

    $("#breadcrumb").text(text);
}

function fillWorkspace() {
    $('#workspaceList').empty();
    var proxy = new ServiceProxy(Settings.T3APIUrl);
    var workspace = new Workspaces();
    proxy.getWorkSpace(workspace);

    $(workspace.WorkSpaceItems).each(function (j, item) {
        var option = $('<option  value="' + item + '"></option>');
        $('#workspaceList').append(option);
    });
}

function fillPipeline() {
    $('#pipelineList').empty();

    var pipeline = new Pipelines();
    var proxy = new ServiceProxy(Settings.T3APIUrl + $("#txtWorkspace").val().trim());
    proxy.getPipeLines(pipeline);

    $(pipeline.PipeLineItems).each(function (j, item) {
        var option = $('<option value="' + item + '"></option>');
        $('#pipelineList').append(option);
    });
}

function fillEvent() {
    $('#eventList').empty();
    var proxy = new ServiceProxy(Settings.T3APIUrl + $.trim($("#txtWorkspace").val().trim()) + "/" + $.trim($("#txtPipeline").val().trim()));

    proxy.getEvents(events);

    $(events.EventItems).each(function (j, item) {
        var option = $('<option value="' + item + '"></option>');
        $('#eventList').append(option);
    });
}