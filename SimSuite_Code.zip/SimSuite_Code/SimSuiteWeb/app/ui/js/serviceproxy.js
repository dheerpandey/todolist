function ServiceProxy(serviceEndpoint) {
    // Add object properties like this
    this.EndPoint = serviceEndpoint;
}

function setHeader(xhr) {
    xhr.setRequestHeader({ 'Access-Control-Allow-Origin': '*' });
}


 ServiceProxy.prototype.getTrends = function () {
        var trends = [];
        $.ajax({
            url: this.EndPoint,
            cache: false,            
            type: "GET",            
            async: false, 
            success: function (data) {
                if (data.length) {
                    $.each(data, function (i, dataset) {
                        var obj = new Trends();
                        obj.Type = dataset.type;
                        obj.Threshold = dataset.threshold;

                        $.each(dataset.datasets, function (i, trends) {
                            var trendDataPoints = [];
                            var label = "";
                            $.each(trends.data, function (j, trend) {
                                var firstKey = Object.keys(trend)[0];
                                if (firstKey.indexOf(".") == 0 && firstKey.indexOf("/") != -1) {
                                    label = firstKey;
                                } else {
                                    trendDataPoints.push({ x: firstKey, y: trend[firstKey] });
                                }
                            })

                            obj.Datasets.push({ trendDataPoints: trendDataPoints, label: label });
                        })
                        trends.push(obj);
                    })
                }

        },
            error: function (error) {
                console.log(error);
        }
    
        });
  return trends;
 }
 

 ServiceProxy.prototype.updateConfig = function () {
     $.ajax({
         url: this.EndPoint,
         cache: false,
         type: "GET",
         async: false,
         success: function (data) {
             console.log(data);
         },
         error: function (error) {
             console.log(error);
         }
     }); 
 }

 ServiceProxy.prototype.reCalculate = function () {
     var response = [];
     $.ajax({
         url: this.EndPoint,
         cache: false,
         type: "GET",
         async: false,
         success: function (data) {
             response = data;
         },
         error: function (error) {
             console.log(error);
         }
     });
     return response;
 }

 ServiceProxy.prototype.getWorkSpace = function (workspace) {
     $.ajax({
         url: this.EndPoint,
         cache: false,
         type: "GET",
         async: false,
         success: function (data) {
             if (data) {
                 $.each(data.Workspaces, function (j, data) {
                     workspace.WorkSpaceItems.push(data.Name);
                 })
             }
         }
     })
 }

 ServiceProxy.prototype.getPipeLines = function (pileLine) {

     $.ajax({
         url: this.EndPoint,
         cache: false,
         type: "GET",
         async: false,
         success: function (data) {
             if (data) {
                 $.each(data.Pipelines, function (j, data) {
                     pileLine.PipeLineItems.push(data.Name);
                 })
             }
         }
     })
 }

 ServiceProxy.prototype.getEvents = function (objEvents) {
     $.ajax({
         url: this.EndPoint,
            cache: false,            
            type: "GET",            
            async: false, 
            success: function (data) {
                if (data) {
                 objEvents.Sections = [];
                 $.each(data.Sections, function (j, section) {
                     objEvents.Sections.push(section.Name);
                 })
                 objEvents.EventItems = [];
                 $.each(data.Events, function (j, data) {
                     objEvents.EventItems.push(data.Name);
                 })
             }             
         }
     })
 }
