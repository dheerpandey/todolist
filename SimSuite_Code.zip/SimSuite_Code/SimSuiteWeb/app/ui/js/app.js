var Settings = new function () {
    this.T3APIUrl = "http://prakashvm/ttt/";
    this.TemplatePath = "app\\ui\\templates\\";
    this.Preferences = Preferences();
}