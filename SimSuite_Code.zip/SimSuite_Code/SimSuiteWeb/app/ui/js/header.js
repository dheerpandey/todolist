﻿var $navMenuButton = $("#navMenu");

var $suiteMenuBackground = $("#suite-menu-background");
var $suiteMenuWindow = $(".wwonline-slim-header-suite-menu-window");
var $suiteMenuButton = $("#appSuite");

var $accountMenuBackground = $("#account-menu-background");
var $accountMenuWindow = $(".wwonline-slim-header-account-menu-window");
var $accountMenu = $("#account-menu");

$("#manageContentLink").click(function (e) {
    notifyDrawerMenuClick("manageContent");
    closeMenuDrawer();
});

// Nav Menu
$navMenuButton.on("touchend", function (e) {
    e.stopPropagation();
    e.preventDefault();
    openMenuDrawer();
    return false;
});

$(".wwonline-slim-header-suite-menu-window > div").click(function () {
    var target = $(this).data("url-target");
    var url = $(this).data("url");

    if (target !== undefined) {
        window.open(url, target);
        $suiteMenuBackground.animate({
            "top": "-10px", "opacity": "toggle"
        }, 250);
    } else {
        location.href = url;
    }
});

// Account Menu
$accountMenu.on("click touchend", function (e) {
    e.stopPropagation();
    e.preventDefault();
    $accountMenuBackground.animate({
        "top": "0", "opacity": "toggle"
    }, 250);
    $accountMenuWindow.css("left", 20 + $accountMenu.position().left - ($accountMenuWindow.width() - $accountMenu.width()));
});


// Tooltips
function createTooltipHandler($tooltip) {
    var $tooltipOwner = $("#" + $tooltip.attr("for"));
    $tooltipOwner.on("mouseenter", function () {
        $tooltip.css("top", 66);
        var toolTipForcedRight = $tooltip.css("right") == "auto" ? 0 : $tooltip.css("right");
        $tooltip.css("left", ($tooltipOwner.position().left - toolTipForcedRight + ($tooltipOwner.outerWidth() / 2)) - ($tooltip.outerWidth() / 2));
        $tooltip.show();
    });

    $tooltipOwner.on("touchmove touchend mouseleave click", function () {
        $tooltip.hide();
    });
} 

function openMenuDrawer() {
    $(".mdl-layout__drawer-right, .mdl-layout__obfuscator").addClass("is-visible");
}

function closeMenuDrawer() {    
    $('.mdl-layout__drawer-right').removeClass('active');
} 

$(document).ready(function () {
    $('#settings').on("click touchend", function () {
        if ($('.mdl-layout__drawer-right').hasClass('active')) {
            $('.mdl-layout__drawer-right').removeClass('active');
        }
        else {
            $('.mdl-layout__drawer-right').addClass('active');
            fillWorkspace();
        }
    });

    $(".page-content").on("click touchend", function () {
        closeMenuDrawer();
    });

    $('.mdl-layout__obfuscator-right').on("click touchend", function () {
        if ($('.mdl-layout__drawer-right').hasClass('active')) {
            $('.mdl-layout__drawer-right').removeClass('active');
        }
        else {
            $('.mdl-layout__drawer-right').addClass('active');
        }
    });
});