﻿function Trends() {
    this.Type = "";
    this.Threshold = [];
    this.Datasets = [{}];
}