﻿function Pipelines() {
    this.Type = "";
    this.PipeLineItems = [];
}