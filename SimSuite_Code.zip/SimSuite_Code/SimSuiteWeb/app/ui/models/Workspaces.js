﻿function Workspaces() {
    this.Type = "";
    this.WorkSpaceItems = [];
}