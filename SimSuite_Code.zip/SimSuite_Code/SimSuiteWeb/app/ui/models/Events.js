﻿function Events() {
    this.Sections = [];
    this.EventItems = [];
}