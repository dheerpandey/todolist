﻿
function Preferences() {    
    return {
        Get: function () {
            var obj = GetFromLocalStorage("CustomerPreference");
            if (obj) {
                return JSON.parse(obj);
            }
            else {
                return;
            }
            
        },
        Add: function (workspace, pipeline, event, date_start,date_end) {

            var str = JSON.stringify({ Workspace: workspace, Pipeline: pipeline, Event: event, DataStart: date_start, DataEnd: date_end });

            SaveToLocalStorage("CustomerPreference", str);
        }
    }
}